from bs4 import BeautifulSoup
import requests
import io

f = open("link.txt", "r").read().split("/")
a=f[0]
b=a
for c in f:
    b=c
d="https://scholar.google.com/scholar?hl=en&as_sdt=0%2C5&q="+a+"%2F"+b+"&btnG="
#print(f.read()) 'https://doi.org/10.1109/CUBE.2013.19'

source = requests.get(d).text

soup = BeautifulSoup(source,'lxml')


s=str(soup)

#with io.open("a.txt", "w", encoding="utf-8") as f:
#    f.write(s)

#f.close()

with io.open("b.txt", "w", encoding="utf-8") as f:
    f.write(s)

f.close()

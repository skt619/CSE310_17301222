public class Pand {
    private String DOI;
    private String Name;
    public Pand(String DOI,String Name){
        this.DOI=DOI;
        this.Name=Name;
    }   
    public String getDOI(){
        return DOI;
    }
    public String getName(){
        return Name;
    }
}
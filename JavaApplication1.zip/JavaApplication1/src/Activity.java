
import java.sql.Timestamp;

public class Activity {
    private String User;
    private String DOI;
    private Timestamp time;

    
public Activity(String User,String DOI, Timestamp time){

 this.User=User;
 this.DOI=DOI;
 this.time=time;

 
}   
 public String getUser(){
 return User;
 } 
 public String getDOI(){
 return DOI;
 }
 public Timestamp gettime(){
 return time;
 }
 
}
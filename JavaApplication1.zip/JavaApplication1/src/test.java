import java.io.*;
import java.util.*;
import java.lang.String;


import java.io.BufferedReader;
import java.io.FileReader;
import java.util.regex.Pattern;
public class test {
  public static void main(String[] args) throws Exception {
    try {
      
      
      File file = new File("b.txt"); 
      
      BufferedReader br = new BufferedReader(new FileReader(file)); 
      //link--site--name--citation-open/closed
      String [][] str= new String[10][5];
      for(int i=0;i<str.length;i++){
        str[i][0]="none";
        str[i][1]="";
        str[i][2]="";
        str[i][3]="0";
        str[i][4]="closed";
      }
      boolean valid=false;
      int item=-1;
      String st;
      
      while ((st = br.readLine()) != null){
        if(st.contains("<h3 class=\"gs_rt\" ontouchstart=\"gs_evt_dsp(event)\"><")//FOR NAME
             ||st.contains("<div class=\"gs_or_ggsm\" ontouchstart=\"gs_evt_dsp(event)\" tabindex=\"-1\"><a data-clk=")//FOR LINK
             ||st.contains("Cited by ")){//FOR CITATION
          if(st.contains("Cited by ")&&item>=0){
            str[item][3]=st.split("Cited by ")[1].split("</a>")[0];
            
          }
          
          //if(st.contains("h3 class=\"gs_rt\" ontouchstart=\"gs_evt_dsp")){
          
          if(st.contains("<h3 class=\"gs_rt\" ontouchstart=\"gs_evt_dsp(event)\"><")){
            item++;valid=true;
            if(st.contains("<div class=\"gs_or_ggsm\" ontouchstart=\"gs_evt_dsp(event)\" tabindex=\"-1\"><")){
              str[item][0]=st.split("<div class=\"gs_or_ggsm\" ontouchstart=\"gs_evt_dsp")[1].split("href=\"")[1].split("\">")[0]; str[item][4]="open";            
            }
            
            
            String[] s1=st.split("h3 class=\"gs_rt\" ontouchstart=\"gs_evt_dsp");
            String sr1;
            String sr2;
            if(s1[1].contains("href=\"http")){
              s1=s1[1].split("href=\"")[1].split("\" id");
              //System.out.println(s1[0]);
              String[] s2=s1[1].split("\">")[1].split("</a>");
              if(st.contains("HTML")){
                str[item][0]=s1[0];
              }
              sr1=s1[0];
              sr2=s2[0];
              
            }else{
              sr1="none";
              sr2=s1[1].split("> <span id=\"")[1].split(">")[1].split("</")[0];
              if(st.contains("Cited by ")){
                str[item][3]=st.split("Cited by ")[1].split("</")[0];
//                System.out.println(st);System.out.println();System.out.println();System.out.println();
              }
            }
            str[item][1]=sr1;
            str[item][2]=sr2;
            
//            System.out.println(str[item][0]);
//            System.out.println(str[item][1]);
//            System.out.println(str[item][2]);
//            System.out.println(str[item][3]);
//            System.out.println(str[item][4]);
            
          }
        }
      }
      String ing=item+1+System.lineSeparator();
      if(valid){
        int i=0;
        for(String[] as:str){
          for(int j=0;j<as.length;j++){
            
            ing+=as[j]+"AAAA";
            
          }ing+=System.lineSeparator();i++;if(i>item) break;
        }
        
        
        
      }
      else{
        
        PrintWriter writer1 =null;      
        writer1 = new PrintWriter(new File("a.txt"));
        
        writer1.write("invalid");                                                   
        writer1.flush();  
        writer1.close();  
        
      }
      
      PrintWriter writer1 =null; 
      
      writer1 = new PrintWriter(new File("a.txt"));  
      writer1.write(ing);                                                   
//      writer1.flush();  
      writer1.close();  
      
    } catch (IOException ex) {}
  }
  
  
}


